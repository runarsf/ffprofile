// ==UserScript==
// @name        Vim Vixen Vix
// @namespace   Violentmonkey Scripts
// @match       *://*/*
// @grant       GM_addStyle
// @run-at      document-start
// @version     1.1
// @author      -
// @description Fixes white bottom bar on dark themed web pages when using Vim Vixen - https://github.com/ueokande/vim-vixen/issues/1424
// ==/UserScript==
GM_addStyle(".vimvixen-console-frame {height: 0px; color-scheme: light !important;}");